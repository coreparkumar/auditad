var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_dotenv = __toESM(require("dotenv"), 1);
var import_vite = require("vite");
var import_genai = require("@google/genai");
import_dotenv.default.config();
var PORT = 3e3;
var HOST = "0.0.0.0";
async function startServer() {
  const app = (0, import_express.default)();
  app.use(import_express.default.json());
  let aiClient = null;
  function getGeminiClient() {
    if (!aiClient) {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
        throw new Error("GEMINI_API_KEY is not configured in environment secrets.");
      }
      aiClient = new import_genai.GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build"
          }
        }
      });
    }
    return aiClient;
  }
  app.get("/api/health", (req, res) => {
    res.json({ status: "healthy", timestamp: (/* @__PURE__ */ new Date()).toISOString() });
  });
  app.post("/api/audit", async (req, res) => {
    try {
      const { manifestText, appName } = req.body;
      if (!manifestText || manifestText.trim().length === 0) {
        return res.status(400).json({ error: "No manifest text or configuration provided for auditing." });
      }
      const ai = getGeminiClient();
      const prompt = `
        You are an expert mobile security and privacy auditor specializing in Android. 
        Your task is to analyze the following Android manifest, list of permissions, dependency records, or configurations for ${appName || "Custom Application"}.
        Identify any privacy risks, background telemetry sync adapters, ad SDK receivers (like AppLovin, Unity Ads, Ironsource), location tracking liabilities, or excessive permissions.

        Analyze:
        """
        ${manifestText}
        """

        Provide your assessment strictly according to the requested JSON layout. Ensure the risk score is a number between 0 and 100 based on realistic risk rules.
      `;
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          systemInstruction: "You are a professional Android privacy and security auditor. You must output an absolute JSON object assessing the provided text. Keep summaries professional, straightforward, and compact.",
          responseMimeType: "application/json",
          responseSchema: {
            type: import_genai.Type.OBJECT,
            properties: {
              riskScore: {
                type: import_genai.Type.INTEGER,
                description: "Realistic calculated security risk score from 0 (perfect safety) to 100 (critical threat)."
              },
              summary: {
                type: import_genai.Type.STRING,
                description: "A professional, user-focused 2-3 sentence summary of the security and privacy findings."
              },
              liabilities: {
                type: import_genai.Type.ARRAY,
                items: {
                  type: import_genai.Type.OBJECT,
                  properties: {
                    name: { type: import_genai.Type.STRING, description: "Name of the excessive permission, tracker SDK, or background process liability." },
                    level: { type: import_genai.Type.STRING, description: "Threat severity level: 'Low', 'Medium', or 'High'." },
                    explanation: { type: import_genai.Type.STRING, description: "Brief explanation of why this is a liability and what privacy index is compromised." }
                  },
                  required: ["name", "level", "explanation"]
                }
              },
              mitigations: {
                type: import_genai.Type.ARRAY,
                items: { type: import_genai.Type.STRING },
                description: "List of actionable steps or DNS block rules to neutralize these liabilities."
              },
              dnsHostnameSuggestion: {
                type: import_genai.Type.STRING,
                description: "A suggested custom upstream blocklist hostname or private DNS endpoint (e.g. adguard, nextdns match) specific to this type of app."
              }
            },
            required: ["riskScore", "summary", "liabilities", "mitigations", "dnsHostnameSuggestion"]
          }
        }
      });
      const responseText = response.text;
      if (!responseText) {
        throw new Error("Empty response returned from Gemini API.");
      }
      const auditResult = JSON.parse(responseText.trim());
      res.json(auditResult);
    } catch (error) {
      console.error("Express Gemini Audit Endpoint Error:", error);
      res.status(500).json({
        error: error.message || "Failed to complete security audit. Please ensure your Gemini API key is configured.",
        isConfigError: error.message?.includes("GEMINI_API_KEY")
      });
    }
  });
  if (process.env.NODE_ENV !== "production") {
    console.log("Setting up Express server with Vite middleware...");
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    console.log("Setting up Express server for production static serving...");
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, HOST, () => {
    console.log(`Express server running on http://${HOST}:${PORT}`);
  });
}
startServer();
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
//# sourceMappingURL=server.cjs.map
